"""
Modelo fisico. Iteracion 1 + Iteracion 2.

Tablas de Iteracion 1 (sin cambios de proposito, ver Iteration 1
Proposal v0.2 seccion 9 y correccion CODE-CR-01):
    - object_version
    - approved_state_pointer
    - approved_state_commit
    - audit_event

Tablas nuevas de Iteracion 2 (Iteration 2 Proposal v0.4 + IC-31):
    - workflow_transition (registro append-only de transiciones
      EFECTIVAMENTE aplicadas del Instructional Object Lifecycle -
      nunca recibe una fila para un intento rechazado)

Generalizada en Iteracion 2 (migracion 0002, compatible hacia atras -
CR-29):
    - idempotency_operation: pasa de ser exclusiva de
      ApprovedStateCommit (Iteracion 1) a un mecanismo de reserva de
      concurrencia compartido entre ApprovedStateCommit y
      WorkflowTransition, discriminado por operation_type. El
      comportamiento observable de Iteracion 1 no cambia: para
      operation_type='APPROVED_STATE_COMMIT', 'REJECTED' nunca se usa,
      y STATE_CONFLICT sigue sin persistir fila (ROLLBACK ALL total,
      sin excepcion).

No se crean en esta iteracion: routing_contract, agent_run,
agent_run_attempt, human_approval_wait_state. Llegan en iteraciones
posteriores.

Invariantes de integridad relacional (CR-19, CR-20, Iteracion 1):
    - object_version tiene UNIQUE(object_id, object_version_id) para que
      pueda ser el destino de foreign keys compuestas.
    - approved_state_pointer.(object_id, current_approved_version_id)
      referencia object_version.(object_id, object_version_id) via FK
      compuesta -> la base de datos rechaza que el puntero de un
      object_id apunte a una version de otro object_id.
    - approved_state_commit.(object_id, object_version_id) referencia la
      misma UNIQUE compuesta -> la base de datos rechaza un commit cuyo
      object_version pertenezca a un object_id distinto del declarado.

Invariantes de idempotency_operation (CR-25, CR-30, IC-31, Iteracion 2):
    - Clave primaria compuesta (operation_type, idempotency_key): la
      misma cadena de idempotency_key usada en una operacion de
      ApprovedStateCommit y en una de WorkflowTransition no colisiona,
      porque la unicidad se evalua sobre el par, no sobre la clave sola.
    - CHECK ck_idempotency_operation_operation_type (IC-31): dominio
      cerrado de operation_type, exactamente
      ('APPROVED_STATE_COMMIT', 'WORKFLOW_TRANSITION') - ninguna otra
      cadena es aceptada por la base de datos, no solo por disciplina
      de codigo.
    - CHECK ck_idempotency_operation_row_invariants (CR-30): hace
      IMPOSIBLE a nivel de base de datos que exista una fila
      APPROVED_STATE_COMMIT + REJECTED, y que cualquier fila tenga
      referencias cruzadas contradictorias entre commit_id,
      transition_id y rejected_reason.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    ForeignKeyConstraint,
    PrimaryKeyConstraint,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID as PG_UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


# Vocabulario completo del Instructional Object Lifecycle, tal como esta
# documentado en Agent Specification v1.1 FINAL BASELINE CANDIDATE,
# Seccion 6.10.3. No se trunca ni se renombra (CR-21). HUMAN_APPROVAL_REQUIRED
# / HUMAN_APPROVAL_NOT_REQUIRED / HUMAN_APPROVAL_CONDITIONALLY_REQUIRED
# NO pertenecen a este vocabulario - son valores de
# RoutingResolutionRecord.resolution (Fase 1, CR-10), confirmado por
# revision humana en Iteration 2 Proposal v0.3.
KNOWN_STATES: tuple[str, ...] = (
    "NOT_ELIGIBLE",
    "ELIGIBLE_PENDING",
    "DRAFT",
    "QA_IN_PROGRESS",
    "REVISION_REQUIRED",
    "QA_PASS_PROVISIONAL",
    "DEPENDENCY_RESOLUTION",
    "DEPENDENCY_BLOCKED",
    "ROUTING_RESOLUTION",
    "READY_FOR_HUMAN_APPROVAL",
    "APPROVED_CONTENT",
    "SUPERSEDED",
)

_known_states_sql_list = ", ".join(f"'{s}'" for s in KNOWN_STATES)


class ObjectVersion(Base):
    __tablename__ = "object_version"

    object_version_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    object_id: Mapped[str] = mapped_column(String, nullable=False)
    version_number: Mapped[int] = mapped_column(nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False)
    supersedes_version_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("object_version.object_version_id"),
        nullable=True,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint(
            "object_id", "object_version_id", name="uq_object_version_object_id_version_id"
        ),
        # Iteracion 2, CR-21: status restringido al vocabulario COMPLETO
        # del Instructional Object Lifecycle aprobado, no a un subconjunto.
        CheckConstraint(
            f"status IN ({_known_states_sql_list})",
            name="ck_object_version_status_known_states",
        ),
    )


class ApprovedStatePointer(Base):
    __tablename__ = "approved_state_pointer"

    object_id: Mapped[str] = mapped_column(String, primary_key=True)
    current_approved_version_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), nullable=True
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )

    __table_args__ = (
        ForeignKeyConstraint(
            ["object_id", "current_approved_version_id"],
            ["object_version.object_id", "object_version.object_version_id"],
            name="fk_approved_state_pointer_object_version",
        ),
    )


class ApprovedStateCommit(Base):
    __tablename__ = "approved_state_commit"

    commit_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    object_id: Mapped[str] = mapped_column(String, nullable=False)
    object_version_id: Mapped[uuid.UUID] = mapped_column(PG_UUID(as_uuid=True), nullable=False)
    expected_previous_approved_version_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), nullable=True
    )
    actual_previous_approved_version_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), nullable=True
    )
    idempotency_key: Mapped[str] = mapped_column(String, nullable=False)
    idempotency_payload_hash: Mapped[str] = mapped_column(String, nullable=False)
    # CODE-CR-01: esta fila SOLO se inserta una vez que la mutacion del
    # puntero ya tuvo exito, dentro de la misma transaccion atomica que
    # tambien inserta el AuditEvent. El unico valor posible es
    # 'COMMITTED'. Sin cambios en Iteracion 2.
    outcome: Mapped[str] = mapped_column(String, nullable=False, default="COMMITTED")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("idempotency_key", name="uq_approved_state_commit_idempotency_key"),
        ForeignKeyConstraint(
            ["object_id", "object_version_id"],
            ["object_version.object_id", "object_version.object_version_id"],
            name="fk_approved_state_commit_object_version",
        ),
        CheckConstraint(
            "outcome = 'COMMITTED'",
            name="ck_approved_state_commit_outcome_committed_only",
        ),
    )


class WorkflowTransition(Base):
    """
    Registro append-only de una transicion EFECTIVAMENTE aplicada del
    Instructional Object Lifecycle (Iteracion 2, CR-22/CR-23/CR-24).

    Nunca recibe una fila para un intento rechazado (UNKNOWN_STATE,
    TRANSITION_NOT_ENABLED_THIS_ITERATION, STATE_CONFLICT,
    INVALID_OBJECT_VERSION) - esos resultados viven exclusivamente en
    idempotency_operation (CR-25, CR-27, CR-28).
    """

    __tablename__ = "workflow_transition"

    transition_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    object_version_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("object_version.object_version_id"),
        nullable=False,
    )
    from_state: Mapped[str] = mapped_column(String, nullable=False)
    to_state: Mapped[str] = mapped_column(String, nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String, nullable=False)
    idempotency_payload_hash: Mapped[str] = mapped_column(String, nullable=False)
    # CR-24: provenance.
    requested_by: Mapped[str] = mapped_column(String, nullable=False)
    correlation_id: Mapped[str] = mapped_column(String, nullable=False)
    # CR-24: diferido intencionalmente - no hay todavia una cadena causal
    # real que representar (Producer/QA/Routing no existen en Iteracion 2).
    # Columna presente para no requerir una migracion adicional cuando
    # exista un caso real que probar.
    causation_id: Mapped[str | None] = mapped_column(String, nullable=True)
    applied_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    __table_args__ = (
        CheckConstraint(
            f"from_state IN ({_known_states_sql_list})",
            name="ck_workflow_transition_from_state_known",
        ),
        CheckConstraint(
            f"to_state IN ({_known_states_sql_list})",
            name="ck_workflow_transition_to_state_known",
        ),
    )


class IdempotencyOperation(Base):
    """
    Mecanismo de reserva/concurrencia compartido, generalizado en
    Iteracion 2 (CR-25) a partir del mecanismo introducido en Iteracion 1
    para ApprovedStateCommit (correccion CODE-CR-01).

    El INSERT ... ON CONFLICT (operation_type, idempotency_key) DO
    NOTHING sobre esta tabla es el UNICO barrero de concurrencia real
    (constraint de base de datos), y ocurre como el PRIMER statement de
    la transaccion atomica de la operacion correspondiente.

    Semantica por operation_type (CR-27, CR-30, IC-31):
      - APPROVED_STATE_COMMIT: sin cambios respecto a Iteracion 1.
        'REJECTED' NUNCA se usa; un STATE_CONFLICT hace ROLLBACK ALL y
        no deja ninguna fila persistida para ese intento.
      - WORKFLOW_TRANSITION: un resultado rechazado (UNKNOWN_STATE,
        TRANSITION_NOT_ENABLED_THIS_ITERATION, STATE_CONFLICT,
        INVALID_OBJECT_VERSION) SI persiste, vía COMMIT explicito (no
        rollback), para permitir replay identico ante un reintento con
        la misma idempotency_key y el mismo payload (CR-27).

    'status' solo puede tomar 'CLAIMED' (transitorio, invisible fuera de
    la transaccion abierta por aislamiento MVCC), 'COMMITTED' o
    'REJECTED' (este ultimo exclusivo de WORKFLOW_TRANSITION). Ninguna
    fila commiteada queda jamas en 'CLAIMED' - se prueba explicitamente
    en los tests de integracion de ambas iteraciones.
    """

    __tablename__ = "idempotency_operation"

    operation_type: Mapped[str] = mapped_column(String, nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String, nullable=False)
    idempotency_payload_hash: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False, default="CLAIMED")
    commit_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("approved_state_commit.commit_id"),
        nullable=True,
    )
    transition_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("workflow_transition.transition_id"),
        nullable=True,
    )
    rejected_reason: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )

    __table_args__ = (
        PrimaryKeyConstraint("operation_type", "idempotency_key", name="idempotency_operation_pkey"),
        # IC-31: dominio cerrado de operation_type.
        CheckConstraint(
            "operation_type IN ('APPROVED_STATE_COMMIT', 'WORKFLOW_TRANSITION')",
            name="ck_idempotency_operation_operation_type",
        ),
        CheckConstraint(
            "status IN ('CLAIMED', 'COMMITTED', 'REJECTED')",
            name="ck_idempotency_operation_status",
        ),
        CheckConstraint(
            "rejected_reason IS NULL OR rejected_reason IN "
            "('UNKNOWN_STATE', 'TRANSITION_NOT_ENABLED_THIS_ITERATION', "
            "'STATE_CONFLICT', 'INVALID_OBJECT_VERSION')",
            name="ck_idempotency_operation_rejected_reason_canonical",
        ),
        # CR-30: invariantes de fila - hace APPROVED_STATE_COMMIT+REJECTED
        # y cualquier referencia cruzada contradictoria imposibles a nivel
        # de base de datos.
        CheckConstraint(
            "(status = 'CLAIMED' AND commit_id IS NULL AND transition_id IS NULL "
            "AND rejected_reason IS NULL) "
            "OR (operation_type = 'APPROVED_STATE_COMMIT' AND status = 'COMMITTED' "
            "AND commit_id IS NOT NULL AND transition_id IS NULL AND rejected_reason IS NULL) "
            "OR (operation_type = 'WORKFLOW_TRANSITION' AND status = 'COMMITTED' "
            "AND commit_id IS NULL AND transition_id IS NOT NULL AND rejected_reason IS NULL) "
            "OR (operation_type = 'WORKFLOW_TRANSITION' AND status = 'REJECTED' "
            "AND commit_id IS NULL AND transition_id IS NULL AND rejected_reason IS NOT NULL)",
            name="ck_idempotency_operation_row_invariants",
        ),
    )


class AuditEvent(Base):
    """
    Alcance minimo de auditoria para Iteracion 1 (CR-17). Sin cambios en
    Iteracion 2 - workflow_transition tiene su propia provenance
    (requested_by, correlation_id) y no depende de esta tabla.
    """

    __tablename__ = "audit_event"

    event_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    event_type: Mapped[str] = mapped_column(String, nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )
    object_id: Mapped[str] = mapped_column(String, nullable=False)
    object_version_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True), nullable=True
    )
    commit_id: Mapped[uuid.UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("approved_state_commit.commit_id"),
        nullable=True,
    )
    payload: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
