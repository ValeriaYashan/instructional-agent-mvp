# MVP Instructional Agent

Slice implementado: `PRODUCE_LEARNING_OBJECT`.

- **Iteracion 1** (HUMAN_APPROVED_CLOSED): fundacion de Approved State
  Pointer / Approved State Commit.
- **Iteracion 2** (este build): Task Intake, Workflow/State Transition
  Manager, `workflow_transition`, generalizacion de
  `idempotency_operation` (CR-25, IC-31).

No incluye Producer, QA, Context Engine, Routing Resolution runtime ni
Human Approval funcional — quedan para iteraciones posteriores.

Documentos autoritativos:
- `MVP TECHNICAL DESIGN — PHASE 1/2/3` (HUMAN_APPROVED)
- `MVP IMPLEMENTATION — ITERATION 1: IMPLEMENTATION PROPOSAL v0.2` (HUMAN_APPROVED_CLOSED)
- `MVP IMPLEMENTATION — ITERATION 2: PROPOSAL v0.4 + IC-31` (HUMAN_APPROVED)

## Iteracion 2 — que se agregó

- **Task Intake**: valida `task_type` contra un catálogo cerrado
  (`PRODUCE_LEARNING_OBJECT`) antes de tocar cualquier tabla.
- **Workflow/State Transition Manager**: único dueño de las
  transiciones del Instructional Object Lifecycle. `KNOWN_STATES`
  (vocabulario completo de 12 estados del Architecture Baseline) está
  separado de `ENABLED_TRANSITIONS_ITERATION_2` (única entrada:
  `ELIGIBLE_PENDING → DRAFT`).
- **`workflow_transition`**: registro append-only de transiciones
  efectivamente aplicadas — nunca recibe una fila para un intento
  rechazado.
- **`idempotency_operation` generalizada**: ahora compartida entre
  `APPROVED_STATE_COMMIT` y `WORKFLOW_TRANSITION`, discriminada por
  `operation_type` (dominio cerrado por CHECK, IC-31). A diferencia de
  Approved State Commit, un resultado rechazado de Workflow Transition
  (`UNKNOWN_STATE`, `TRANSITION_NOT_ENABLED_THIS_ITERATION`,
  `STATE_CONFLICT`, `INVALID_OBJECT_VERSION`) sí persiste, para permitir
  replay idéntico ante un reintento con la misma `idempotency_key`.
- Migración `0002`, compatible hacia atrás con una base ya poblada por
  Iteración 1 (`0001` permanece inmutable).

## Requisitos

- Python 3.12
- [uv](https://docs.astral.sh/uv/) (gestor de dependencias aprobado)
- Docker + Docker Compose (para PostgreSQL local y para los tests de
  integracion via testcontainers)

## Instalacion

```bash
uv sync --all-extras
```

Esto instala `sqlalchemy`, `psycopg[binary]`, `alembic` (dependencias de
runtime) y `pytest` + `testcontainers[postgres]` (dependencias de
desarrollo, definidas en `[tool.uv].dev-dependencies`).

## Levantar PostgreSQL local

```bash
docker compose up -d
cp .env.example .env
```

Verificar que esta saludable:

```bash
docker compose ps
```

## Aplicar migraciones

```bash
export $(cat .env | xargs)
uv run alembic upgrade head
```

Aplica `0001` (tablas de Iteración 1) y luego `0002` (Iteración 2:
`workflow_transition`, generalización de `idempotency_operation` con
backfill automático de las filas existentes como
`operation_type='APPROVED_STATE_COMMIT'`, CHECK de `KNOWN_STATES` sobre
`object_version.status`). `0002` puede aplicarse tanto sobre una base
vacía como sobre una base ya poblada por Iteración 1 — ver el docstring
de la migración para la secuencia exacta.

## Ejecutar tests

Tests unitarios (no requieren base de datos):

```bash
uv run pytest tests/unit -v
```

Tests de integracion (requieren Docker corriendo — levantan su propio
PostgreSQL 16 efímero via testcontainers, independiente del de
`docker compose`, y aplican las migraciones de Alembic contra ese
contenedor antes de correr):

```bash
uv run pytest tests/integration -v
```

Todos los tests (incluye la regresión obligatoria de Iteración 1 contra
el esquema post-`0002`, CR-29):

```bash
uv run pytest -v
```

## Que cubre la suite de Iteracion 1

- Primera aprobacion desde `NULL` (CR-14)
- Segunda aprobacion valida, avance del puntero
- `STATE_CONFLICT` ante version previa esperada obsoleta, sin fila
  huerfana en `approved_state_commit` (CR-13)
- Idempotencia: mismo `idempotency_key` + mismo payload → mismo
  resultado; mismo `idempotency_key` + payload distinto →
  `IDEMPOTENCY_CONFLICT` (CR-18)
- Integridad relacional cruzada: un puntero o un commit no pueden
  referenciar una version de un `object_id` distinto — forzado a
  nivel de base de datos por foreign keys compuestas (CR-19, CR-20)
- Atomicidad: todo commit exitoso tiene exactamente un `audit_event`
  correspondiente; todo `STATE_CONFLICT` no deja ni commit ni audit
  event huerfanos (CR-13, CR-17)
- Concurrencia: primera aprobacion concurrente (solo una tiene exito);
  la misma `idempotency_key` nunca antes vista, solicitada de forma
  concurrente con el mismo payload, produce exactamente un commit, una
  mutacion de puntero y un audit event — nunca duplicados

## Correccion aplicada tras Human Code Review (CODE-CR-01)

La primera entrega de esta iteracion tenia un defecto de atomicidad:
la reserva de concurrencia para `idempotency_key` se confirmaba
(`COMMIT`) en una transaccion separada, antes de saber si la mutacion
del puntero tendria exito — lo que podia dejar una fila `PENDING`
persistida en `approved_state_commit` sin su mutacion de puntero ni su
`audit_event` correspondientes, violando CR-13.

Correccion: se introdujo una tabla nueva y aislada,
`idempotency_operation`, exclusivamente para la reserva de
concurrencia. Esa reserva se inserta como el **primer statement de la
misma transaccion atomica** que despues valida, muta el puntero,
inserta el `ApprovedStateCommit` final e inserta el `AuditEvent`.
`approved_state_commit.outcome` ahora tiene un `CHECK` que solo
permite `'COMMITTED'` — ya no existe ningun valor `'PENDING'` posible
en esa tabla. El detalle completo del mecanismo de bloqueo esta
documentado en el docstring de `src/persistence/repositories/approved_state.py`.

## Limitaciones conocidas de esta iteracion

- No existe todavia Producer, QA, Context Engine, Routing Resolution
  ni Human Approval Boundary funcional — llegan en iteraciones
  posteriores sobre esta misma fundacion.
- El modelo de `audit_event` es minimo (ver docstring en
  `src/persistence/models.py`), no el modelo completo de Audit Trail
  de Fase 3 (`correlation_id`, `causation_id`, `actor_type`, `run_id`).
- **Los 16 tests nuevos de Iteración 2 (`tests/integration/test_workflow_transition.py`)
  no han sido ejecutados contra un PostgreSQL real en el entorno donde
  se generó este build**, por la misma razón que en Iteración 1: este
  entorno no tiene Docker disponible. Se verificaron estáticamente
  (recolección sin errores de import junto con los 18 tests de
  Iteración 1 — 30 en total —, compilación de todo el DDL nuevo y de
  las sentencias SQL críticas del Workflow Transition Manager contra
  el dialecto PostgreSQL). La suite completa, incluida la regresión
  obligatoria de los 18 tests de Iteración 1 contra el esquema
  post-`0002` (CR-29), debe correrse en una máquina o CI con Docker
  antes de dar por cerrada la Iteración 2. Comando exacto:
  `uv run pytest -v`.
- Los 18 tests de Iteración 1 sí fueron ejecutados y pasaron
  (`14 passed` de integración + `4 passed` unitarios) contra
  PostgreSQL 16 real en GitHub Codespaces, previo a este build — pero
  esa ejecución fue contra el esquema post-`0001` únicamente, antes de
  que existiera `0002`. La regresión contra el esquema post-`0002`
  sigue pendiente de ejecución real.
